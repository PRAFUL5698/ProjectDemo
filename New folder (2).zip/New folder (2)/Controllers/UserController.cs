﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using User.Models;

namespace User.Controllers
{
    public class UserController : Controller
    {
        // GET: User
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult AdminHome()
        {

            return View();

        }
        public ActionResult UserHome()
        {

            return View();

        }

        public ActionResult Login()
        {

            return View();

        }

        [HttpPost]
        public ActionResult Login(Registration reg)
        {
            
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MsSqlLocalDb;Initial Catalog=DOtNetExam;Integrated Security=True;Pooling=False";
            cn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from User_details where UserName = @UserName and Password = @Password";
            cmd.Parameters.AddWithValue("@UserName", reg.UserName);
            cmd.Parameters.AddWithValue("@Password", reg.Password);

            SqlDataReader dr = cmd.ExecuteReader();
          

            if (dr.Read())
            {
                if (Convert.ToString(dr["TypeName"]) == "User")
                {
                    Session["usernm"] = dr["UserName"];
                    return RedirectToAction("UserHome");
                }
                else if (Convert.ToString(dr["TypeName"]) == "Employee")
                {
                    Session["usernm1"] = dr["UserName"];
                    return RedirectToAction("EmployeeHome");
                }
                else if (Convert.ToString(dr["TypeName"]) == "Admin")
                {
                    Session["usernm2"] = dr["UserName"];
                    return RedirectToAction("AdminHome","Admin");

                }
            }


            return View();
      }


        // GET: User/Register
        public ActionResult Register()
        {
            return View();
        }

        // POST: User/Create
        [HttpPost]
        public ActionResult Register(Models.Registration reg)
        {

            try
            {
                SqlConnection cn = new SqlConnection();
                cn.ConnectionString = @"Data Source=(localdb)\MsSqlLocalDb;Initial Catalog=DOtNetExam;Integrated Security=True;Pooling=False";
                cn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into User_Details values(@UserName,@Password,@Name,@MobileNo,@Region,@TypeName)";
                cmd.Parameters.AddWithValue("@UserName", reg.UserName);
                cmd.Parameters.AddWithValue("@Password", reg.Password);
                cmd.Parameters.AddWithValue("@Name", reg.Name);
                cmd.Parameters.AddWithValue("@MobileNo", reg.MobileNo);
                cmd.Parameters.AddWithValue("@Region", reg.Region);
                cmd.Parameters.AddWithValue("@TypeName", reg.TypeName);

                int i = cmd.ExecuteNonQuery();

                return RedirectToAction("index","Home");
                // cn.Close();
            }
            catch (Exception e)
            {
                return View();
            }
        }


        // GET: User/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: User/Create
        [HttpPost]
        public ActionResult Create(Models.User user)
        {

            try
            {
                SqlConnection cn = new SqlConnection();
                cn.ConnectionString = @"Data Source=(localdb)\MsSqlLocalDb;Initial Catalog=DOtNetExam;Integrated Security=True;Pooling=False";
                cn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into Demo values(@Region,@Type,@Description)";
               // cmd.Parameters.AddWithValue("@Id", user.Id);
                cmd.Parameters.AddWithValue("@Region", user.Region);
                cmd.Parameters.AddWithValue("@Type", user.Type);
                cmd.Parameters.AddWithValue("@Description", user.Description);

                int i = cmd.ExecuteNonQuery();

                Console.WriteLine("Hello");

                return RedirectToAction("index");
                // cn.Close();
            }
            catch (Exception e) {
                return View();
            }
        }

        // GET: User/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: User/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: User/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: User/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
