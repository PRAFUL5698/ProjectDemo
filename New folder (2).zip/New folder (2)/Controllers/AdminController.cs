﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace User.Controllers
{
    public class AdminController : Controller
    {


        public ActionResult AdminHome()
        {
            return View();
        }

        // GET: Admin
        public ActionResult Index()
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MsSqlLocalDb;Initial Catalog=DOtNetExam;Integrated Security=True;Pooling=False";
            cn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select Name, Region, MobileNo from User_Details where TypeName = 'User' ";
            SqlDataReader dr = cmd.ExecuteReader();
            List<Models.User> ulist = new List<Models.User>();

            while (dr.Read())
            {
                Models.User u = new Models.User();

                u.Region = dr["Region"].ToString();
                u.Type = dr["TypeName"].ToString();
                u.Description = dr["Description"].ToString();

                ulist.Add(u);
            }

            return View(ulist);
        }

        // GET: Admin/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }


        // GET: Admin/Create
        public ActionResult Registration()
        {
           
            return View();
        }

        // POST: Admin/Create
        [HttpPost]
        public ActionResult Registration(Models.EmpRegistration reg)
        {
            try
            {
                SqlConnection cn = new SqlConnection();
                cn.ConnectionString = @"Data Source=(localdb)\MsSqlLocalDb;Initial Catalog=DOtNetExam;Integrated Security=True;Pooling=False";
                cn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into User_Details values(@UserName,@Password,@Name,@MobileNo,@Region,@TypeName)";
                cmd.Parameters.AddWithValue("@UserName", reg.UserName);
                cmd.Parameters.AddWithValue("@Password", reg.Password);
                cmd.Parameters.AddWithValue("@Name", reg.Name);
                cmd.Parameters.AddWithValue("@MobileNo", reg.MobileNo);
                cmd.Parameters.AddWithValue("@Region", reg.Region);
                cmd.Parameters.AddWithValue("@TypeName", reg.TypeName);

                int i = cmd.ExecuteNonQuery();

                return RedirectToAction("index", "Home");
                // cn.Close();

               
            }
            catch
            {
                return View();
            }
        }


        // GET: Admin/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Admin/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Admin/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Admin/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Admin/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Admin/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
