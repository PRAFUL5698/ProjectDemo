﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace User.Models
{
    public class User
    {
       

        [Required(ErrorMessage = "Please fill the Region")]
        public String Region { get; set; }

        [Required(ErrorMessage = "Please fill the Type of Complaint")]
        public String Type { get; set; }

        [Required(ErrorMessage = "Please fill the Description of Complaint")]
        public String Description { get; set; }

    }
}