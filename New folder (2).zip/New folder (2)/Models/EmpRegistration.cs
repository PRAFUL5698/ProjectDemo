﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace User.Models
{
    public class EmpRegistration
    {

        [Required(ErrorMessage = "Please fill the UserName"), MaxLength(8), MinLength(4)]
        public String UserName { get; set; }


        [Required(ErrorMessage = "Please enter Valid Password"), MaxLength(8), MinLength(4)]
        [Display(Name = "Password")]
        [DataType(DataType.Password)]
        public String Password { get; set; }


        [Required(ErrorMessage = "Please enter Your Name"), MaxLength(20)]
        [Display(Name = "Name")]
        [DataType(DataType.Text)]
        public String Name { get; set; }


        [Required(ErrorMessage = "Please enter Mobile No")]
        public int MobileNo { get; set; }


        public String Region { get; set; }

        public String TypeName { get; set; }

        public EmpRegistration()
        {
            TypeName = "Employee";
        }

    }
}